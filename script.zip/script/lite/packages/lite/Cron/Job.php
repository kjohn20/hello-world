<?php


namespace Lite\Cron;


interface Job
{
	public function run();
}