<?php


namespace Lite\Exceptions;

use JsonException;

class JsonEncodingException extends JsonException
{
	//Exception
}