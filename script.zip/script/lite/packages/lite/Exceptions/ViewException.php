<?php

namespace Lite\Exceptions;

use RuntimeException;

class ViewException extends RuntimeException  {

	//Exception
}