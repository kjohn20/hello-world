<?php
 return [
	'0'=>[
		'id'=>0,
		'text'=>'How to Download',
		'link'=>'how-to-download',
		'external'=>false,
	],
	'1'=>[
		'id'=>1,
		'text'=>'Privacy Policy',
		'link'=>'privacy-policy',
		'external'=>false,
	],
	'2'=>[
		'id'=>2,
		'text'=>'Terms of Services',
		'link'=>'terms-of-services',
		'external'=>false,
	],
];