<?php
 return [
	'name'=>'TikTok Video Downloader',
	'desc'=>'TikTok Video Downloader Without watermark! Now you can download TikTok Videos without any restriction. Just paste your TikTok Video Url and download the video.',
	'keywords'=>'TikTok, TikTok Downloader, TikTok Video Downloader, Download TikTok Videos, Online TikTok Video Downloader, Downnload TikTok Videos Without Watermark',
	'version'=>'2.3.8',
	'cover'=>'cover.jpg',
	'token'=>'0121C3C6-5DF8-4BB0-9BDD-9AD9F9CB6396',
	'api_version'=>'wrapper',
	'theme'=> 'light'
];