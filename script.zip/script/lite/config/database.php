<?php
 return [
	'driver'=>'mysql',
	'host'=>'localhost',
	'database'=>'tiktok',
	'username'=>'root',
	'password'=>'root',
	'charset'=>'utf8mb4',
	'prefix'=>'',
];