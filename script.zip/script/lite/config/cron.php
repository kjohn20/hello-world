<?php
return [
	'delete_video_after'=> '12' //In Hours
];