<?php
 return [
	0=>[
		'text'=>'mail',
		'link'=>'mailto:hasnain.khurshid96@gmail.com',
	],
	1=>[
		'text'=>'facebook',
		'link'=>'http://www.facebook.com',
	],
];