interface Window{
    [key:string]:any
    adsbygoogle?: any
    smoothScroll?:any
}
declare var window: Window;