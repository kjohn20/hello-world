<template>
    <div class="dashboard-grid-group">
        <x-element-recent-search />
        <x-element-top-search />
    </div>
</template>

<script>
    export default {
        name: "Dashboard"
    }
</script>