<?php


namespace App\Resources;


use Lite\Http\JsonResources;

class PagesResource extends JsonResources
{
	//Nothing
}