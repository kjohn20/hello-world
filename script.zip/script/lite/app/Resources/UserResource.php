<?php


namespace App\Resources;


use Lite\Http\JsonResource;

class UserResource extends JsonResource
{
	//Nothing Here
}