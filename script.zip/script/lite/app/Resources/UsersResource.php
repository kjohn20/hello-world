<?php


namespace App\Resources;


use Lite\Http\JsonResources;

class UsersResource extends JsonResources
{
	//Nothing
}