<?php


namespace App\Resources;


use Lite\Http\JsonResources;

class VideoResources extends JsonResources
{

}