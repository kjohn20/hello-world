<?php


namespace App\Resources;


use Lite\Http\JsonResource;

class PageResource extends JsonResource
{
	//Nothing Here
}