<?php


namespace App\Resources;


use Lite\Http\JsonResource;

class VideoResource extends JsonResource
{

}