<section id="welcome" class="center show">
    <h1>TikTok Video Downloader Installation</h1>
    <p>Welcome! TikTok Video Downloader is an online webscraper which allows you to scrape TikTok video links to download Videos without watermark</p>
    <p class="mb-40"><b>Installation process is very easy and it takes less than 2 minutes!</b></p>
    <button>
    Start Installation
    </button>
</section>