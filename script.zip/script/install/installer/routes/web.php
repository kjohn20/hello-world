<?php
/**
 * @var \Lite\Routing\Router $router
 */
$router->get('/','InstallerController@index');