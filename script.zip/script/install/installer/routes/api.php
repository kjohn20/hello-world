<?php
/**
 * @var \Lite\Routing\Router $router
 */

 $router->post('install','InstallerController@install');

